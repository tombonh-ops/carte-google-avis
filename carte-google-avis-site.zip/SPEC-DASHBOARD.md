# Spécification — Redirection & tableau de bord

Ce document décrit le minimum à construire pour que les promesses du site soient
tenues. Il ne décrit pas une application mobile : il n'y en a pas besoin (voir
« PWA » plus bas).

---

## La contrainte qui commande tout le reste

Le site et les CGV promettent, noir sur blanc :

> lien court **modifiable à vie**, tableau de bord **sans limitation de durée**,
> **sans abonnement ni frais récurrents**, pour **40 € payés une fois**.

Autrement dit : **Tom encaisse une fois et doit héberger le service pour toujours.**
Chaque client ajoute un coût d'infrastructure permanent et aucun revenu récurrent.

La conséquence est directe : **le coût marginal par client doit être proche de zéro,
et le rester.** Ce n'est pas un détail de confort technique, c'est ce qui décide si le
modèle à 40 € tient dans cinq ans ou s'effondre.

Ordre de grandeur, pour fixer les idées : 100 restaurants × ~200 scans/mois = environ
**20 000 requêtes par mois**. C'est très peu. Le tout tient largement dans les paliers
gratuits décrits plus bas — et il faudrait plusieurs milliers de restaurants avant d'en
sortir.

---

## Principe : deux services séparés, pas un

| | Redirection | Tableau de bord |
|---|---|---|
| Rôle | Résoudre `/r/slug` → Google, compter | Afficher les stats, modifier le lien |
| Criticité | **Vitale** | Confort |
| Si c'est en panne | **Toutes les cartes de tous les restaurants sont mortes** | Personne ne s'en aperçoit avant longtemps |
| Fréquence d'usage | Des milliers de fois | Quelques fois par an |

Ces deux choses n'ont ni la même exigence ni le même risque. **Il faut les séparer.**
La redirection doit être un service minuscule, sans dépendance, qui ne tombe jamais.
Le tableau de bord peut être plus riche et moins critique.

C'est le choix d'architecture le plus important du projet.

---

## Pile recommandée : Cloudflare

**Redirection** — Cloudflare Workers + KV
**Données** — Cloudflare D1 (SQLite)
**Tableau de bord** — Cloudflare Pages
**Emails de connexion** — Resend (palier gratuit : 3 000 emails/mois)

Pourquoi celle-là plutôt qu'une autre :

- **Le palier gratuit autorise l'usage commercial.** Attention : le palier *Hobby* de
  Vercel ne l'autorise pas. Y héberger un service vendu est une violation des conditions
  d'utilisation — il faudrait passer en Pro à 20 $/mois.
- **Rien ne se met en veille.** Le palier gratuit de Supabase suspend la base après
  quelques jours d'inactivité. Sur un service de redirection, une base endormie =
  **toutes les cartes en panne** le temps du réveil. Rédhibitoire ici.
- **La redirection s'exécute en périphérie**, au plus près du téléphone. Le client est
  debout au comptoir : chaque centaine de millisecondes compte.
- Workers : 100 000 requêtes **par jour** gratuites. D1 : 5 Go. Largement au-dessus des
  besoins réels.

*Alternative si Tom préfère rester sur ce qu'il connaît* : Next.js sur Vercel Pro
(20 $/mois) + Supabase Pro (25 $/mois) = **45 $/mois**, soit l'équivalent d'une vente et
demie par mois uniquement pour l'hébergement. Sur un modèle sans revenu récurrent, c'est
un choix coûteux — mais plus rapide à construire s'il maîtrise déjà la pile.

---

## Modèle de données

```sql
CREATE TABLE restaurants (
  slug        TEXT PRIMARY KEY,          -- 'chez-antoine-lyon' — IMPRIMÉ SUR LA CARTE
  name        TEXT NOT NULL,             -- 'Chez Antoine'
  city        TEXT,
  google_url  TEXT NOT NULL,             -- destination, modifiable à volonté
  owner_email TEXT NOT NULL,             -- sert à la connexion
  created_at  TEXT NOT NULL DEFAULT (datetime('now')),
  active      INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE scans (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  slug       TEXT NOT NULL REFERENCES restaurants(slug),
  scanned_at TEXT NOT NULL,              -- ISO 8601, UTC
  source     TEXT NOT NULL DEFAULT 'nfc' -- 'nfc' | 'qr'
);
CREATE INDEX idx_scans_slug_date ON scans (slug, scanned_at);

-- Historique des modifications de lien : très utile au support
CREATE TABLE link_changes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  slug       TEXT NOT NULL REFERENCES restaurants(slug),
  old_url    TEXT,
  new_url    TEXT NOT NULL,
  changed_at TEXT NOT NULL DEFAULT (datetime('now'))
);
```

### Ce que la table `scans` ne contient pas, et pourquoi

**Ni adresse IP, ni user-agent, ni cookie, ni identifiant.** Uniquement un horodatage et
la source. Ce n'est pas de la timidité : la politique de confidentialité publiée engage
Tom sur exactement ce point —

> « Ces compteurs sont agrégés et ne constituent pas un profil des visiteurs finaux ;
> aucune donnée nominative sur les clients de votre restaurant n'est collectée. »
> « Ce site ne dépose aucun cookie publicitaire ni traceur de mesure d'audience. »

Conséquence assumée : **on compte des scans, pas des personnes.** Si un client tape deux
fois, ça compte deux fois. C'est exactement ce que dit la page (« chaque scan est
compté »), donc la promesse reste honnête. Ne pas être tenté d'ajouter un cookie de
déduplication : cela ferait basculer le site dans l'obligation de bannière de consentement,
pour un gain nul.

Le « par jour **et par service** » promis sur la page se déduit de l'heure du scan
(midi / soir), sans aucune donnée supplémentaire.

---

## Le service de redirection

**Route :** `GET /r/:slug` — optionnellement `?s=qr` pour distinguer QR et NFC.

```js
export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);
    const slug = url.pathname.replace(/^\/r\//, '').replace(/\/$/, '').toLowerCase();

    if (!slug) return Response.redirect('https://www.cartegoogleavis.fr/', 302);

    // KV : lecture en périphérie, quelques millisecondes
    const dest = await env.LINKS.get(slug);

    // Slug inconnu : ne jamais afficher une erreur brute au client du restaurant
    if (!dest) {
      return Response.redirect('https://www.cartegoogleavis.fr/carte-inconnue.html', 302);
    }

    // Le comptage ne doit JAMAIS retarder la redirection
    ctx.waitUntil(
      env.DB.prepare(
        'INSERT INTO scans (slug, scanned_at, source) VALUES (?, ?, ?)'
      ).bind(
        slug,
        new Date().toISOString(),
        url.searchParams.get('s') === 'qr' ? 'qr' : 'nfc'
      ).run().catch(() => {})   // une panne de comptage ne casse pas la redirection
    );

    return new Response(null, {
      status: 302,
      headers: {
        Location: dest,
        'Cache-Control': 'no-store, max-age=0'
      }
    });
  }
};
```

### Trois règles à ne jamais enfreindre

1. **Jamais de redirection 301.** Une 301 est *permanente* : les navigateurs et les
   opérateurs la mettent en cache indéfiniment. Le jour où le restaurateur modifie son
   lien, les téléphones qui ont déjà scanné continueraient d'aller à l'ancienne adresse
   — **pour toujours**. Ce seul caractère détruirait la promesse « modifiable à vie ».
   Toujours 302, avec `Cache-Control: no-store`.

2. **Le comptage ne bloque jamais la redirection.** `ctx.waitUntil` lance l'écriture
   après avoir rendu la réponse. Si la base est indisponible, le client va quand même
   sur Google — on perd une statistique, pas une vente.

3. **Un slug imprimé sur une carte ne change plus jamais**, et n'est jamais réattribué à
   un autre restaurant. Une carte dans la nature pointe dessus pour toujours. En cas de
   changement d'établissement, on modifie la **destination**, pas le slug.

### Synchronisation KV ↔ base

KV est la source de vérité **en lecture** (rapide), D1 en **écriture** (fiable). À chaque
modification de lien : écrire dans D1, puis `env.LINKS.put(slug, newUrl)`. KV se propage
en quelques secondes dans le monde entier — cohérent avec le « en un clic » promis.

---

## Les écrans

### Écran 0 — Back-office de Tom (`/admin`)

Le seul écran indispensable au lancement. Sans lui, Tom ne peut livrer personne.

- Liste des restaurants : nom, ville, scans du mois, statut
- **Créer un restaurant** : nom, ville, email du propriétaire, lien Google
  → génère le slug, écrit en D1, pousse dans KV
- **Modifier le lien** de n'importe quel client (support de premier niveau)
- Bouton **« Générer le QR »** (image PNG du lien `/r/slug?s=qr`)
- Accès protégé — un simple mot de passe d'environnement suffit au début

### Écran 1 — Connexion client (`/login`)

- Un champ email, un bouton. Envoi d'un **lien magique** valable 30 minutes.
- **Pas de mot de passe.** Un restaurateur se connecte deux fois par an : il aurait
  oublié son mot de passe à chaque fois, et chaque réinitialisation est un appel au
  support pour Tom.

### Écran 2 — Tableau de bord (`/`)

L'écran principal. Reprendre exactement la maquette du hero du site, qui montre déjà
au futur client ce qu'il obtiendra :

- Nom du restaurant + pastille « En ligne »
- Trois compteurs : **aujourd'hui / ce mois / au total**
- Graphe en barres sur **14 jours**
- Le lien actuel affiché en clair + bouton **Modifier**
- Téléchargements : **QR code (PNG)** et **chevalet (PDF)**

### Écran 3 — Modifier le lien (`/lien`, ou une fenêtre modale)

- Champ de saisie + validation du format (voir ci-dessous)
- Avertissement explicite : *« Prend effet immédiatement sur la carte, le chevalet et
  le sticker. »*
- Enregistrement dans `link_changes` — indispensable quand un client appellera en
  disant « ça ne marche plus » après avoir collé un mauvais lien.

**Validation du lien** — accepter uniquement :
`https://g.page/r/…/review`, `https://search.google.com/local/writereview?placeid=…`,
`https://maps.app.goo.gl/…`. Refuser tout le reste avec un message clair. C'est la
première cause de panne évitable.

---

## Le manifest PWA

À poser sur le **tableau de bord** (`app.cartegoogleavis.fr`), surtout pas sur la page
de vente : personne n'installe une page marketing.

`manifest.json` :

```json
{
  "name": "Carte Google Avis",
  "short_name": "Mes avis",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "background_color": "#F5F2EB",
  "theme_color": "#1E5C41",
  "icons": [
    { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
    { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" },
    { "src": "/icon-512-maskable.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable" }
  ]
}
```

Dans le `<head>` :

```html
<link rel="manifest" href="/manifest.json">
<meta name="theme-color" content="#1E5C41">
<link rel="apple-touch-icon" href="/icon-180.png">
```

Les couleurs reprennent celles du site (`--paper` et `--green`) pour que l'écran de
lancement soit cohérent avec la marque.

**Sur iPhone**, l'installation passe par Safari → Partager → « Sur l'écran d'accueil ».
Ce n'est pas évident pour tout le monde : **c'est à Tom de le faire pendant
l'installation**, sur place, en trente secondes. C'est aussi un moment de service qui
justifie son prix.

---

## Ordre de construction

**1. La redirection + KV.**
Dès que `cartegoogleavis.fr/r/test` renvoie vers une fiche Google et compte le passage,
**le produit est vendable**. C'est le seul jalon vraiment bloquant.

**2. Le back-office de Tom.**
Avec ça, il peut livrer et dépanner des clients **à la main**, sans que le tableau de
bord client existe. Il peut vendre pendant qu'il construit la suite.

**3. Le tableau de bord client.**
À faire quand il y a des clients qui le réclament — pas avant.

**4. La PWA.**
Une demi-heure, une fois le tableau de bord en place.

Cette séquence a une conséquence importante : **Tom peut encaisser sa première vente
après l'étape 1**, pas après l'étape 4.

---

## Points opérationnels à régler

**Trouver le lien d'avis d'un restaurant.** Le plus simple est de le demander au
restaurateur : dans son profil Google Business, « Demander des avis » fournit un lien
court `g.page/r/…/review`. Sinon, le construire depuis le Place ID :
`https://search.google.com/local/writereview?placeid=PLACE_ID`.
Ne pas deviner : un mauvais lien envoie les clients chez un concurrent.

**Générer le QR.** Une bibliothèque côté serveur (`qrcode` en Node) suffit. Le QR doit
pointer vers `https://www.cartegoogleavis.fr/r/slug?s=qr` — jamais directement vers
Google, sinon on perd la modification à vie et le comptage.

**Sauvegardes.** Exporter la table `restaurants` chaque semaine. Perdre les scans est
regrettable ; perdre la correspondance slug → lien Google rendrait **toutes les cartes
en circulation inutilisables**, sans moyen de les récupérer.

**Page « carte inconnue ».** Créer `carte-inconnue.html` : une page sobre qui explique
que la carte n'est pas encore activée, avec le contact WhatsApp. Elle sera vue par de
vrais clients de restaurants — elle ne doit jamais ressembler à une erreur technique.

---

## Ce qu'il ne faut pas construire

- **Une application native.** Voir plus haut : quatre ouvertures par an, 99 $/an, deux
  plateformes à maintenir. La PWA couvre le besoin.
- **Un système de comptes multi-utilisateurs, des rôles, une facturation intégrée.**
  Tom a zéro client. Un email suffit comme identifiant.
- **Des analyses fines des visiteurs.** Interdit par sa propre politique de
  confidentialité, et sans intérêt pour le restaurateur.
