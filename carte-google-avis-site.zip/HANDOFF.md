# Passation — nouveau site Carte Google Avis

Site statique complet (HTML/CSS/JS vanilla, zéro dépendance, polices auto-hébergées).
Déployable tel quel sur Vercel, Netlify, Cloudflare Pages ou n'importe quel hébergeur —
ou portable vers le projet Next.js existant (voir plus bas).

## Fichiers

| Fichier | Rôle |
|---|---|
| `index.html` | Page unique de vente (restaurants) |
| `mentions-legales.html` / `cgv.html` / `confidentialite.html` | Pages légales obligatoires |
| `assets/styles.css` | Design system complet |
| `assets/fonts.css` + `fonts/*.woff2` | Polices auto-hébergées (RGPD : zéro requête vers Google Fonts) |
| `assets/site.js` | Menu mobile, FAQ, animations (2 Ko) |
| `sitemap.xml`, `robots.txt`, `icon.svg` | SEO / favicon |

## ⚠️ À FAIRE AVANT MISE EN LIGNE (bloquant)

1. **SIRET + identité** — remplir toutes les zones surlignées en jaune (`mark.todo`)
   dans le footer et les 3 pages légales. Vendre en ligne sans immatriculation est illégal.
2. **Formulaire** — créer un formulaire gratuit sur [formspree.io](https://formspree.io)
   et remplacer `VOTRE_ID` dans `index.html` (ligne du `<form>`). Sans ça, le bouton
   d'envoi ne mène nulle part. Alternative : brancher l'API du projet Next.js.
3. **Email pro** — créer `contact@cartegoogleavis.fr` (redirection gratuite chez la
   plupart des registrars) vers la boîte de Tom.
4. **Image Open Graph** — créer `og-image.png` (1200×630) et la placer à la racine.
   Sujet : la carte + le titre « L'avis Google se gagne à table. » sur fond vert #1E5C41.
5. **Médiateur de la consommation** — en désigner un (obligatoire dès la première vente
   à un client assimilé consommateur) et compléter l'article 12 des CGV.
6. **Délai de livraison** — remplacer « X jours ouvrés » dans les CGV (article 6).
7. **Statistiques de la section « Les chiffres »** — vérifier les deux sources avant
   mise en ligne et garder les liens sous la main en cas de question :
   - « 9/10 Français lisent les avis » → étude IFOP pour Guest Suite (vague la plus récente).
   - « +5 à 9 % de CA par étoile » → Michael Luca, *Reviews, Reputation, and Revenue:
     The Case of Yelp.com*, Harvard Business School (restaurants indépendants).
   Si une source ne convient pas, remplacer le chiffre — ne jamais l'inventer.

## Décisions produit reflétées par le site (à confirmer par Tom)

- **Prix : 40 €, une fois, sans abonnement** (décision de Tom). Le « sans abonnement »
  est affiché comme un argument (hero, tarif, FAQ), à la manière de nor.ma. Garantie
  carte : 1 an incluse, ensuite remplacement à prix coûtant. Piste de revenus
  complémentaires : options facultatives (2e carte, chevalet pro, multi-établissements).
- **Promesse « sans engagement »** : si le client arrête, la redirection de base vers
  sa page Google **reste active à vie**. C'est écrit sur la page, dans la FAQ et dans
  les CGV (article 9). Tom doit l'honorer — un redirect coûte ~0 €, la confiance
  qu'il achète est énorme. Ne jamais prendre le lien en otage.
- **Aucun chiffre de résultat promis** (« +40 % d'avis » etc.) : illégal sans preuve,
  et la FAQ Q3 transforme cette honnêteté en argument (« on mesure au lieu de promettre »).
- **Sollicitation de TOUS les clients, sans tri** : affirmé sur la page, en footer et
  dans les CGV. C'est ce qui rend l'offre conforme (règles Google + DGCCRF).
- **Le dashboard doit fournir au minimum** : compteur de scans par jour, modification
  du lien, téléchargement du QR. C'est ce que la page vend — pas plus, pas moins.

## La plateforme (redirection + tableau de bord)

Le site vend un lien court modifiable et un tableau de bord. **Tant que le service de
redirection n'existe pas, la promesse n'est pas tenable.** La spécification complète
est dans **`SPEC-DASHBOARD.md`** : architecture, modèle de données, code de la
redirection, les trois écrans, manifest PWA et ordre de construction.

À retenir en une ligne : **dès que `/r/slug` redirige et compte, le produit est
vendable** — le tableau de bord client peut venir après.

## Photos « En situation » — À FAIRE EN PRIORITÉ

La section `#en-situation` (`#in-situ` en anglais) contient **trois marque-places**
visibles, marqués « À remplacer ». **Ne pas mettre la page en ligne tant qu'ils y sont.**

Les trois photos à prendre (le téléphone suffit — lumière du jour, pas de flash,
cadrage horizontal, format 4:3, le premier en 16:9) :

1. **Le comptoir** — la carte posée près de la caisse, plan large, on doit voir le
   décor du restaurant.
2. **Le geste** — une main qui approche le téléphone de la carte. *C'est la photo la
   plus importante des trois* : c'est elle qui explique le produit sans un mot.
3. **Le chevalet** — le chevalet QR sur une table dressée, posé avec l'addition.

**Comment les poser :** créer un dossier `photos/` à la racine, y déposer les images
(idéalement < 300 Ko chacune, en `.jpg` ou `.webp`), puis dans `index.html` remplacer
chaque bloc `<div class="shot-ph">…</div>` par :

```html
<img src="photos/comptoir.jpg" alt="Carte NFC posée près de la caisse d'un restaurant"
     width="1600" height="1200" loading="lazy">
```

Le cadrage, le survol et l'animation d'entrée sont déjà gérés par le CSS — il n'y a
rien d'autre à toucher. Penser à faire la même chose dans `en/index.html` (chemin
`../photos/…`) et à rédiger un `alt` descriptif, pas « photo 1 ».

**Important :** demander l'accord du restaurant avant de publier une photo de son
établissement, et ne pas laisser apparaître de client identifiable sans son accord.

## Version anglaise

Le site existe en anglais dans le dossier `en/` (`en/index.html`, `en/legal-notice.html`,
`en/terms.html`, `en/privacy.html`). Il partage le même CSS, le même JS et les mêmes
polices que la version française — rien à dupliquer.

- **Sélecteur FR/EN** dans l'en-tête et le pied de page de chaque page.
- **Détection automatique** : un visiteur dont le navigateur est en anglais *et pas en
  français* est redirigé vers `/en/` à sa première visite. Son choix manuel est ensuite
  mémorisé (localStorage) et la redirection ne se redéclenche jamais.
- **Pour désactiver la redirection** : passer `AUTO_REDIRECT` à `false` en haut de
  `assets/site.js`. Le sélecteur FR/EN continue de fonctionner.
- **Attention SEO** : la redirection automatique s'applique aussi aux robots dont la
  langue déclarée est l'anglais (c'est souvent le cas de Googlebot). Les balises
  `hreflang` et le `sitemap.xml` indiquent les deux versions, mais si Tom constate que
  la page française est mal indexée, c'est le premier réglage à désactiver.
- **Pages légales anglaises** : ce sont des traductions d'information. Chacune porte un
  encadré indiquant que **seule la version française fait foi** — ne pas retirer cet
  encadré, c'est ce qui protège Tom si un litige portait sur une formulation traduite.
- La calculette et les libellés dynamiques s'adaptent seuls à la langue de la page
  (`<html lang>`), y compris le format des nombres.

## Prochaines étapes (après mise en ligne)

- **Photos réelles** : la carte sur un vrai comptoir de restaurant, main + téléphone.
  À insérer en hero à la place / à côté du mockup. Un après-midi de shooting suffit.
- **Deux premiers clients** (même à prix cassé) → ajouter une section de vrais
  témoignages **signés et vérifiables**. Jamais d'inventés.
- **Fiche Google de Carte Google Avis elle-même** : créer le profil, récolter ses
  propres avis. Premier argument de vente en démarchage.
- **Portage Next.js** (si souhaité) : copier les sections + le CSS ; corriger
  `metadataBase` dans `app/layout.tsx` (cause du bug og:url=localhost de l'ancien
  site) ; retirer « Admin » de la nav publique ; réparer le 503 de /admin.

## Ce qui a été corrigé par rapport à l'ancien site

| Audit | Correction |
|---|---|
| T-01 og:localhost | URLs OG absolues en dur |
| T-02 faux témoignages | Supprimés — remplacés par l'offre de lancement (vrais témoignages à venir) |
| T-03 formulaire mailto | Vrai `<form>` POST avec labels, names, consentement RGPD, honeypot |
| T-04 lien Admin public | Retiré |
| T-05 zéro page légale | 3 pages complètes (zones à remplir surlignées) |
| T-06 pas de paiement | CTA → formulaire → lien de paiement ; à brancher sur Stripe |
| T-07 zéro SEO | JSON-LD (Organization, Product, FAQPage), sitemap, canonical, semantic HTML |
| T-08 Gmail perso | contact@cartegoogleavis.fr partout |
| D-01 palette Tailwind | Palette propre : papier chaud / vert bistrot / or étoile |
| D-02 Inter 900 | Fraunces (display) + Instrument Sans (UI) + Spline Sans Mono (data) |
| D-03 zéro visuel produit | Mockup dashboard + carte NFC illustrée (photos réelles à suivre) |
| D-04 page monotone | Alternance papier / bento / bande sombre |
| D-05 features sans preuves | Discours mécanisme + mesure ; zéro promesse invérifiable |
| D-06 FAQ complaisante | 6 vraies objections, y compris Amazon à 3 € et le zéro-frais après achat |
| D-07 pas de sémantique | header/nav/main/section/footer, labels, skip-link, aria, focus visible |
| B-03 monétise le plastique | Offre = système (lien + stats + dashboard), vendu one-shot par choix |
| B-04 « clients satisfaits » | Copie 100 % conforme : tous les clients, sans tri |
| B-05 pas de cible | Restaurants uniquement, vocabulaire métier (addition, comptoir, service) |
