/* Carte Google Avis — interactions légères, zéro dépendance */
(function () {
  'use strict';

  /* ------------------------------------------------------------------
     LANGUE
     AUTO_REDIRECT : passer à false pour désactiver la redirection
     automatique vers /en/ (le sélecteur FR/EN continue de fonctionner).
     Voir HANDOFF.md — section « Version anglaise ».
     ------------------------------------------------------------------ */
  var AUTO_REDIRECT = true;

  var isEN = document.documentElement.lang === 'en';
  var LOCALE = isEN ? 'en-GB' : 'fr-FR';
  var T = isEN ? {
    months: function (n) { return n === 1 ? '1 month' : n.toLocaleString(LOCALE) + ' months'; },
    firstReviews: 'first reviews in month one',
    toDouble: function (n) { return 'to double your current ' + n + ' reviews'; }
  } : {
    months: function (n) { return n === 1 ? '1 mois' : n.toLocaleString(LOCALE) + ' mois'; },
    firstReviews: 'premiers avis dès le premier mois',
    toDouble: function (n) { return 'pour doubler vos ' + n + ' avis actuels'; }
  };

  // Mémorise le choix manuel : une fois choisi, on ne redirige plus jamais.
  var store = function (key, val) { try { localStorage.setItem(key, val); } catch (e) {} };
  var read = function (key) { try { return localStorage.getItem(key); } catch (e) { return null; } };

  document.querySelectorAll('[data-lang]').forEach(function (a) {
    a.addEventListener('click', function () { store('cga-lang', a.getAttribute('data-lang')); });
  });

  // Détection automatique — premier passage seulement, et jamais en local.
  if (AUTO_REDIRECT && !isEN && !read('cga-lang') && /^https?:$/.test(location.protocol)) {
    var langs = navigator.languages || [navigator.language || ''];
    var wantsEN = false, wantsFR = false;
    for (var i = 0; i < langs.length; i++) {
      var l = String(langs[i]).toLowerCase();
      if (l.indexOf('fr') === 0) wantsFR = true;
      if (l.indexOf('en') === 0) wantsEN = true;
    }
    if (wantsEN && !wantsFR) {
      store('cga-lang', 'en');
      location.replace('/en/' + location.hash);
      return;
    }
  }

  // Header : bordure au scroll
  var header = document.querySelector('.site-header');
  if (header) {
    var onScroll = function () {
      header.classList.toggle('scrolled', window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  // Menu mobile
  var toggle = document.querySelector('.nav-toggle');
  var links = document.querySelector('.nav-links');
  if (toggle && links) {
    toggle.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    links.addEventListener('click', function (e) {
      if (e.target.closest('a')) {
        links.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      }
    });
  }

  // Révélation au scroll (respecte prefers-reduced-motion via CSS)
  if ('IntersectionObserver' in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach(function (el) { io.observe(el); });
  } else {
    document.querySelectorAll('.reveal').forEach(function (el) { el.classList.add('in'); });
  }

  // FAQ : une seule question ouverte à la fois
  var faqs = document.querySelectorAll('.faq-item');
  faqs.forEach(function (item) {
    item.addEventListener('toggle', function () {
      if (item.open) {
        faqs.forEach(function (other) { if (other !== item) other.open = false; });
      }
    });
  });

  // Compteurs animés (section chiffres)
  var reduceMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var counters = document.querySelectorAll('.count');
  if (counters.length && 'IntersectionObserver' in window && !reduceMotion) {
    var cio = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        cio.unobserve(entry.target);
        var el = entry.target;
        var to = parseInt(el.getAttribute('data-to'), 10) || 0;
        var t0 = null, dur = 900;
        var tick = function (t) {
          if (!t0) t0 = t;
          var p = Math.min((t - t0) / dur, 1);
          el.textContent = String(Math.round(to * (1 - Math.pow(1 - p, 3))));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
    }, { threshold: 0.6 });
    counters.forEach(function (el) { cio.observe(el); });
  }

  // Calculette d'écart — arithmétique simple, aucune promesse
  var slider = document.getElementById('c-couverts');
  if (slider) {
    var sliderVal = document.getElementById('c-couverts-val');
    var avisInput = document.getElementById('c-avis');
    var segBtns = document.querySelectorAll('.seg button');
    var rClients = document.getElementById('r-clients');
    var rAvis = document.getElementById('r-avis');
    var rDouble = document.getElementById('r-double');
    var rDoubleLab = document.getElementById('r-double-lab');
    var jours = 6;
    var fmt = function (n) { return n.toLocaleString(LOCALE); };
    var update = function () {
      var couverts = parseInt(slider.value, 10);
      var avis = Math.max(0, parseInt(avisInput.value, 10) || 0);
      var clients = Math.round(couverts * jours * 4.33 / 10) * 10;
      var plus = Math.max(1, Math.round(clients / 100));
      sliderVal.textContent = String(couverts);
      rClients.textContent = '≈ ' + fmt(clients);
      rAvis.textContent = '+' + fmt(plus);
      if (avis === 0) {
        rDouble.textContent = fmt(plus);
        rDoubleLab.textContent = T.firstReviews;
      } else {
        var mois = Math.max(1, Math.ceil(avis / plus));
        rDouble.textContent = T.months(mois);
        rDoubleLab.textContent = T.toDouble(fmt(avis));
      }
    };
    slider.addEventListener('input', update);
    avisInput.addEventListener('input', update);
    segBtns.forEach(function (btn) {
      btn.addEventListener('click', function () {
        jours = parseInt(btn.getAttribute('data-jours'), 10);
        segBtns.forEach(function (b) { b.classList.remove('on'); b.setAttribute('aria-pressed', 'false'); });
        btn.classList.add('on');
        btn.setAttribute('aria-pressed', 'true');
        update();
      });
    });
    update();
  }

  // Barre de progression de lecture
  var bar = document.querySelector('.scroll-progress i');
  if (bar && !reduceMotion) {
    var ticking = false;
    var draw = function () {
      var max = document.documentElement.scrollHeight - window.innerHeight;
      var pct = max > 0 ? (window.scrollY / max) * 100 : 0;
      bar.style.width = Math.min(100, Math.max(0, pct)) + '%';
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; requestAnimationFrame(draw); }
    }, { passive: true });
    window.addEventListener('resize', draw, { passive: true });
    draw();
  }

  // CTA mobile collante — visible après le hero, masquée sur la zone de commande
  var sticky = document.querySelector('.sticky-cta');
  if (sticky) {
    var zoneCommande = document.getElementById('contact');
    var surCommande = false;
    if (zoneCommande && 'IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        surCommande = entries[0].isIntersecting;
        sticky.classList.toggle('hide', surCommande);
      }, { rootMargin: '0px 0px -25% 0px' }).observe(zoneCommande);
    }
    var onStickyScroll = function () {
      sticky.classList.toggle('show', window.scrollY > 640);
    };
    window.addEventListener('scroll', onStickyScroll, { passive: true });
    onStickyScroll();
  }

  // Année courante
  var year = document.getElementById('year');
  if (year) year.textContent = String(new Date().getFullYear());
})();
